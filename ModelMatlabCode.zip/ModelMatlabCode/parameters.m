% Dimensions
qs = 6; % set up a qs-by-qs grid
w = 9; % nearest neigbor distance units
nx = (qs+1)*w + qs; 
ny = nx;
dx = 0.1; dy = dx;
Lx = dx*(nx-1)/2; Ly = Lx; 

% Cell
Ci = 30.0; 
gamma = 1.90; 
Cm = 1.0e6; 

% Nutrient
Ni = 5; %5 * ( (73 * 73) / 36 ) /  ( (153 * 153) / (qs^2) ); %5;          
epsi = 0.8; 
sN = 0; 

% Antibiotics
%Ai = 40; 
kappaB = 2.0e-1; 
ddA = 0;
sA = 0; 
Ath = 5; % antibiotic threshold concentration for lysis


% Beta-lactamase
Bi = 0;
ddB = 1.20e-2;

% Diffusion
DN = 1; % Diffusion coefficient for the growth-limiting nutrient; for glucose (of 2.99 x 10^-22 g/molecule, 1nm of diameter) at 25 C in water in square milimeters per hour
DC = 2.0e-16; % Diffusion coefficient representing cell movement
DA = 0.8e-1; % Diffusion coefficient for carbenicillin (of 6.79 x 10^-22 g/molecule, ? of diameter)
DB = 1.0e-4; %1.0e-3; % Diffusion coefficient for beta-lactamase (beta lactam inhibitor) 29 kDa (4.82 x 10^-20 g/molecule, ~2 nm of diameter) in size

% Time steps
dt     = 0.0025 * (dx^2) / max([DN, DC, DA, DB]); %0.00005; % time step
totalt = 240; % imagine that 1 unit =~ 0.5 h with the default growth rate (mu)
nt     = totalt / dt + 1;
