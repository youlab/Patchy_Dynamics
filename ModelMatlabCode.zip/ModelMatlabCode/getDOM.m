function [MatV1, MatV2, MatU1, MatU2] = getDOM(nx, ny, dx, dy, dt, D)

rx = dt / dx^2;
ry = dt / dy^2;
I = speye(nx);
e = ones(nx, 1);

Mx = spdiags([e -2*e e], -1:1, nx, nx);
My = spdiags([e -2*e e], -1:1, ny, ny);
Mx(1, 2) = 2; Mx(nx, nx - 1) = 2;
My(2, 1) = 2; My(ny - 1, ny) = 2;

MatV1 = I - rx / 2 * D * Mx; MatV2 = I + rx / 2 * D * Mx;
MatU2 = I - ry / 2 * D * My; MatU1 = I + ry / 2 * D * My;
end