% Dimensions
Lx = 2.5; %40;  
Ly = Lx; 
dx = 0.1; %Lx/100; % Lx/50;
dy = dx;
nx = 2 * Lx / dx + 1; 
ny = 2 * Ly / dy + 1;

% Cell
Ci = 30.0; % mean initial cell density, %1.50 - 1.55 are patch-generating values that cannot survive when inoculated homogeneously 
gamma = 1.90; % 2.20 or 3.50 
Cm = 1.0e6; %1.0e3;

% Nutrient
Ni = 5; % 4         
epsi = 0.8; % nutrient recycling constant (from lysed biomass)
sN = 0; %5.0e-4 ; % nutrient influx

% Antibiotics
Ai = 0;
kappaB = 2.0e-1; %2.0e-1;
ddA = 0; %7.5e-3;
sA = 0; %1.0e-1; % antibiotic influx

% Beta-lactamase
Bi = 0;
ddB = 1.20e-2; % 4.0e-2

% Diffusion
DN = 1; %always 1 % Diffusion coefficient for the growth-limiting nutrient; for glucose (of 2.99 x 10^-22 g/molecule, 1nm of diameter) at 25 C in water in square milimeters per hour
DC = 2.0e-16; % Diffusion coefficient representing cell movement
DA = 0.8e-1; % Diffusion coefficient for carbenicillin (of 6.79 x 10^-22 g/molecule, ? of diameter)
DB = 1.0e-4; %1.0e-3; % Diffusion coefficient for beta-lactamase (beta lactam inhibitor) 29 kDa (4.82 x 10^-20 g/molecule, ~2 nm of diameter) in size

% Time steps
dt     = 0.0025 * (dx^2) / max([DN, DC, DA, DB]); %0.00005; % time step
totalt = 240; % imagine that 1 unit =~ 0.5 h with the default growth rate (mu)
nt     = totalt / dt + 1;