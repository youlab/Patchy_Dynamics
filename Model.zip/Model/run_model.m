% Author: Emrah Simsek
% Latest update: 13-Aug-2022

clear
clc
close all

% set(0,'DefaultFigureVisible','off')

tic

Ath = 5;

parameters
condition = 'conditionName';

tarih_saat = datetime;

tarih = yyyymmdd(tarih_saat);

mkdir([num2str(tarih) '/Results'])

tint = 12;

tt = totalt/tint + 1;

Cminr = 1.0e-9;

% numerical stability check
ns = max([DN, DC, DA, DB]) * dt / (dx^2);

if ns > 1/4
    fprintf(['Numerical stability is not guaranteed ( n_s = ' num2str(ns) ' ) ... \n'])
    fprintf(['Choose an at least ' num2str(ns/0.25) ' smaller timestep (or maximum diffusion coefficient) ... \n'])
end

% Initial conditions
Lx = 3.6;

x  = linspace(-Lx, Lx, nx+22);
y  = linspace(-Ly, Ly, ny+22);

[xx, yy] = meshgrid(x, y);
rr = sqrt(xx .^ 2 + yy .^ 2);

N = zeros(ny+22, nx+22) + Ni;
A = zeros(ny+22, nx+22) + Ai;
B = zeros(ny+22, nx+22) + Bi;
w = 10;

%%% uncomment when sampling a new initial cell density matriz
% C = zeros(ny, nx);
% 
% rng('shuffle')
% 
% q = 0;
% 
% for j = 1:w:size(C,2)
%     
%     for i = 1:w:size(C,2)
%     
%         C(j,i) = normrnd(Ci, 0.4*Ci, 1, 1);
% 
%         q = q + 1;
%         
%     end
% 
% end
% 
% C(C < 0) = 0;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% for loading a previously used C
load 'Test_C_tau0_20210525_04.mat'
q = 36; %number of the local populations- has to be a complete square;
% 

% used for tiling the edges to reduce the edge effects
Ctile1 = [zeros(11, ny); C; zeros(11, ny)] ;
Ctile = [zeros(size(Ctile1,1), 11), Ctile1, zeros(size(Ctile1,1), 11) ];
%

% save the initial cell density matrix after tiling
C = Ctile;

[row, col] = find(C>0);

Cimat = C;


i = 0;

%%% uncomment for saving the initial cell density matrix
% save([pwd '/' num2str(tarih) '/Results/' condition '_Test_C_tau' num2str(i*dt) '.mat'], 'C')
%%%

    % fig0 = figure('visible', 'off'); %figure(1);
    fig0 = figure(1);
    imagesc(Cimat)
    axis off;
    colorbar()
    % caxis([0 500])
    title(['Ab = ' num2str(Ai) ', \tau = ' num2str(0)])
    set(gca, 'FontSize', 24)
    filename0 = [pwd '/' num2str(tarih) '/Results/Ab' num2str(Ai) 'tau0.jpg'];
    saveas(fig0, filename0)


[MatV1N, MatV2N, MatU1N, MatU2N] = getDOM(nx+22, ny+22, dx, dy, dt, DN);
[MatV1A, MatV2A, MatU1A, MatU2A] = getDOM(nx+22, ny+22, dx, dy, dt, DA);
[MatV1B, MatV2B, MatU1B, MatU2B] = getDOM(nx+22, ny+22, dx, dy, dt, DB);
[MatV1C, MatV2C, MatU1C, MatU2C] = getDOM(nx+22, ny+22, dx, dy, dt, DC);

tau_save_vec = [0.0000 100.0000 200.0000];

qq = 2; 

Ctransient = zeros(tt, q);
Ttransient = zeros(tt, 1);
Atransient = zeros(tt, 1);
Ntransient = zeros(tt, 1);

Atransient(1, 1) = sum(A(:));
Ntransient(1, 1) = sum(N(:));
Ttransient(1, 1) = i;

for kk=1:q
        
    Ctransient(1, kk) = C(col(kk), row(kk));
                
end
    
  
for i = 1 : nt
    
    % ------------ Reaction ------------
    g = (N ./ (N + 1)) .* (1 - (C / Cm) );
    
    l = zeros(size(A,1), size(A,2));
    
    for iii = 1:size(A,1)
        
        for jjj = 1:size(A,2)
            
            if A(iii, jjj)>=Ath
                
                l(iii, jjj) = gamma .* g(iii, jjj);
                
            else
                
                l(iii, jjj) = 0;
                
            end
            
        end
        
    end
    
    
    dC = (g - l) .* C;
    dN = (epsi * l - g) .* C + sN;
    dA = - kappaB * B .* A - ddA * A + sA;
    dB = l .* C - ddB * B;

    
    N = N + dN * dt; N(N < 0) = 0;
    C = C + dC * dt; C(C < Cminr) = 0;
    A = A + dA * dt; A(A < 0) = 0;
    B = B + dB * dt; B(B < 0) = 0;
    
    % ------------ Diffusion ------------
    
    Cv = MatV1C \ (C * MatU1C); C = (MatV2C * Cv) / MatU2C;
    Nv = MatV1N \ (N * MatU1N); N = (MatV2N * Nv) / MatU2N;    
    Av = MatV1A \ (A * MatU1A); A = (MatV2A * Av) / MatU2A;    
    Bv = MatV1B \ (B * MatU1B); B = (MatV2B * Bv) / MatU2B;
    C(C < Cminr) = 0;

    % -------------------------------------------------------------------
   
    if i*dt == totalt || mod(i*dt, tint) <= 1e-9
    clf; 
    kk = 1;
    
    fig1 = figure(1);
       imagesc(C)
       title(['Cell density at \tau = ' num2str(i*dt) ])
       colorbar()
       set(gca, 'FontSize', 18)
%        oldcmap = colormap('gray');
%        colormap( flipud(oldcmap) );         
%        colorbar()
       drawnow;
%        filename1= [pwd '/' num2str(tarih) '/Results/' condition '_CellDensity_timestep' num2str(i) '.png'];
       filename1 = [pwd '/' num2str(tarih) '/Results/' condition '_Ab' num2str(Ai) '_C_tau' num2str(i*dt) '.png'];
%        saveas(fig1, filename1)

    fig2 = figure('visible', 'off'); %figure(3);
    subplot 221
        pcolor(xx, yy, C); view(2);
        shading interp; axis equal; axis([-Lx Lx -Ly Ly]); 
%         caxis([Ci 1e11])
        title('Cell density')
        colorbar()
        set(gca, 'FontSize', 10)
    subplot 222
        pcolor(xx, yy, N); view(2);
        shading interp; axis equal; axis([-Lx Lx -Ly Ly]);
%         caxis([0 Ni]); 
        title('Nutrient')
        colorbar()
        set(gca, 'FontSize', 10)
    subplot 223
        pcolor(xx, yy, B); view(2); 
        shading interp; axis equal; axis([-Lx Lx -Ly Ly]); 
%         caxis([0 5e-10])
        title('Bla^{extra}')
        colorbar()
        set(gca, 'FontSize', 10)
    subplot 224
        pcolor(xx, yy, A); view(2);
        shading interp; axis equal; axis([-Lx Lx -Ly Ly]);
%         caxis([0 Ai]); 
        title('Antibiotics')
%         oldcmap = colormap('gray');
%         colormap( flipud(oldcmap) );         
        colorbar()
        set(gca, 'FontSize', 10)
        T = sgtitle(['\tau = ' num2str(i*dt) ]);
        T.FontSize = 20;
        T.FontWeight = 'Bold';
    drawnow;
%     filename2= [condition '_StateVariables_timestep' num2str(i) '.jpeg'];
% %     saveas(fig2, filename2)
        for kk=1:q

            Ctransient(qq, kk) = C(col(kk), row(kk));

        end
    
            Ntransient(qq, 1) = sum(N(:));
            Atransient(qq, 1) = sum(A(:));
            Ttransient(qq, 1) = i*dt;
            qq = qq + 1;

    end
   
%%% uncomment for saving the variable matrice at desired time steps    
%     if ismember(single(i*dt), tau_save_vec)
% 
%         save([pwd '/' num2str(tarih) '/Results/' condition '_Ab' num2str(Ai) '_C_tau' num2str(i*dt) '.mat'], 'C')
%         save([pwd '/' num2str(tarih) '/Results/' condition '_Ab' num2str(Ai) '_N_tau' num2str(i*dt) '.mat'], 'N')
%         save([pwd '/' num2str(tarih) '/Results/' condition '_Ab' num2str(Ai) '_A_tau' num2str(i*dt) '.mat'], 'A')
%         save([pwd '/' num2str(tarih) '/Results/' condition '_Ab' num2str(Ai) '_B_tau' num2str(i*dt) '.mat'], 'B')
% 
%     end
%%%

end

fig3 = figure(4); 
scatter(Ctransient(1,:), Ctransient(end,:), 100, 'LineWidth',2)
xlabel({'Initial vertex', '(patch) cell density'})
ylabel({'Final vertex', '(patch) cell density'})
set(gca, 'FontSize', 24)
filename3= [pwd '/' num2str(tarih) '/Results/' condition '_Ab' num2str(Ai) '_localCellDensityCorrGraph.png'];
% saveas(fig3, filename3)


fig5 = figure(6);
imagesc(C)
axis off;
colorbar()
% caxis([0 500])
title(['Ab = ' num2str(Ai) ', \tau = ' num2str(i*dt)])
set(gca, 'FontSize', 24)
filename5 = [pwd '/' num2str(tarih) '/Results/Ab' num2str(Ai) '.jpg'];
saveas(fig5, filename5)

meanCtrans = zeros(size(Ctransient, 1), 1);
maxCtrans = zeros(size(Ctransient, 1), 1);
stdCtrans = zeros(size(Ctransient, 1), 1);
totCtrans = zeros(size(Ctransient, 1), 1);
richCtrans = zeros(size(Ctransient, 1), 1);


for aa=1:size(Ctransient,1)
    
    meanCtrans(aa, 1) = mean(Ctransient(aa,:));
    maxCtrans(aa, 1) = max(Ctransient(aa,:));
    totCtrans(aa, 1) = sum(Ctransient(aa,:));
    stdCtrans(aa, 1) = std(Ctransient(aa,:));
    richCtrans(aa, 1) = length(find(Ctransient(aa,:)));

end

cvCtrans = stdCtrans./meanCtrans;

% export the output matrix "n" into a csv file
colNames1 = {'TimeSample', 'Nutrients', 'Antibiotics'};
sTable1 = array2table([Ttransient, Ntransient, Atransient], 'VariableNames', colNames1);
sTable2 = array2table(Ctransient);
sTable3 = array2table(meanCtrans);
sTable4 = array2table(maxCtrans);
sTable5 = array2table(cvCtrans);
sTable6 = array2table(totCtrans);
sTable7 = array2table(richCtrans);
sTable = [sTable1, sTable2, sTable3, sTable4, sTable5, sTable6, sTable7];
writetable(sTable, [pwd '/' num2str(tarih) '/Results/Ab' num2str(Ai) '_output.csv'])


fig7 = figure(7);
subplot(2,2,1)
plot(Ttransient, richCtrans, 'k-o', 'LineWidth', 2, 'MarkerSize', 6)
xlabel('Time')
ylabel('No. of surviving patches')
ylim([0 q])
set(gca, 'FontSize', 12, 'YTick', 0:q/3:q)
subplot(2,2,2)
plot(Ttransient, Ctransient, 'LineWidth', 2)
xlabel('Time')
ylabel('Patch size')
set(gca, 'FontSize', 12)
subplot(2,2,3)
plot(Ttransient, log10(Ntransient), 'b-o', 'LineWidth', 2, 'MarkerSize', 6)
xlabel('Time')
ylabel('log_{10} Total nutrients')
set(gca, 'FontSize', 12)
subplot(2,2,4)
plot(Ttransient, log10(Atransient), 'r-o', 'LineWidth', 2, 'MarkerSize', 6)
xlabel('Time')
ylabel('log_{10} Total antibiotics')
set(gca, 'FontSize', 12)
T = sgtitle(['Ab = ' num2str(Ai)  ]);
T.FontSize = 18;
T.FontWeight = 'Bold';
filename7 = [pwd '/' num2str(tarih) '/Results/TimeCourse_Ab' num2str(Ai) '.jpg'];
saveas(fig7, filename7)