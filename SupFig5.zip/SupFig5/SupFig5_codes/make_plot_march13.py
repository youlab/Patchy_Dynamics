#re-plot, make prettier. 
#%% 
import matplotlib
from matplotlib import pyplot as plt
import pandas as pd
import numpy as np
import os

#%%
# import matplotlib.font_manager
# from IPython.core.display import HTML

# def make_html(fontname):
#     return "<p>{font}: <span style='font-family:{font}; font-size: 24px;'>a</p>".format(font=fontname)
# code = "\n".join([make_html(font) for font in sorted(set([f.name for f in matplotlib.font_manager.fontManager.ttflist]))])
# HTML("<div style='column-count: 2;'>{}</div>".format(code))

#%%
# plt.title("max patch cell density $(×10^{-3})$")

#%%         
plt.rcParams.update({'mathtext.default': 'regular'})
#plt.title('   '.join(paramdict), fontname = "Helvetica", style = 'italic') 

#%%
param_dict = {
    'epsi': chr(958),
    'DB': "$D_b$",
    'ddB': "$d_b$",
    'kappaB': "$\kappa_b$",
    'DA': "$D_a$",
    'Ath': "$A_{th}$",
    'gamma': "$\gamma$",
    'Cm': "$c_m$"
}
den = {"total_biomass": 1000, 
            "gini": None, 
            "max_patch": 1000, 
            "fracnotzero": 0.01} #times 100 percent . 

yticksdict = {"total_biomass": [0, 10, 20, 30], 
                "gini": [0, 0.5, 1],  
                "max_patch": [0, 10, 20], 
                "fracnotzero": [0, 50, 100]}
valdict = {"total_biomass": "total density $(×10^{-3})$", #patch
           "gini": "Gini", 
           "max_patch": "max density $(×10^{-3})$", #patch
           "fracnotzero": "fraction growing (%)"}

#todo make dict. 
def fax(x, y, v):
    div = den[v]
    badval = -1
    if v == "gini":
        badval = 0
    y = y.round(decimals = 3)
    fax_idx = (y != badval)
    if div is not None:
        y = y / div
    return x[fax_idx], y[fax_idx]


t_s = [84, 240]
imgfolder = "317_plots_v5"
os.mkdir(imgfolder)
for paramname in param_dict.keys():
    for valname in valdict:
        for t in t_s:
            in_dir = "plot_datatables_withnonzerofraction_{}".format(t)
            loadfile = os.path.join(in_dir, "{}_{}.csv".format(paramname, valname))
            dt =pd.read_csv(loadfile)
            plt.rcParams.update({'font.size': 14})
            fig = plt.figure(figsize=(3.96, 3.16)) 
            plt.plot(*fax(dt['initial_antibiotic'], dt['1/4p0'], valname), label = "0.25×", color ='#7C5C00', linewidth = 2)
            plt.plot(*fax(dt['initial_antibiotic'], dt['1/2p0'], valname), label = "0.5×", color ='#C00000', linewidth = 2)
            plt.plot(*fax(dt['initial_antibiotic'], dt['p0'], valname), label = "1×", color ='#000000', linewidth = 2)
            if paramname == "epsi":
                plt.plot(*fax(dt['initial_antibiotic'], dt['5/4p0'], valname), label = "1.25×", color ='#B4C7E7', linewidth = 2)
               # fig.legend(loc='upper right', ncol = 4, prop={'size': 9, 'family': 'Arial'}, bbox_to_anchor=(1, 1))
            else:
                plt.plot(*fax(dt['initial_antibiotic'], dt['2p0'], valname), label = "2×", color ='#B4C7E7', linewidth = 2)
                plt.plot(*fax(dt['initial_antibiotic'], dt['4p0'], valname), label = "4×", color = '#FFC000', linewidth = 2)
               # fig.legend(loc='upper right', ncol = 5, prop={'size': 9, 'family': 'Arial'}, bbox_to_anchor=(1, 1))
            #plt.xlabel("a$_0$", fontname = "Lucida Calligraphy", style = 'italic', fontsize = 20)
            #plt.ylabel(valdict[valname], fontname= 'Arial', fontsize = 20)
            plt.yticks(yticksdict[valname], fontname = "Arial", fontsize = 20)
            plt.xticks([0, 20, 40, 60, 80, 100], fontname = "Arial", fontsize = 20)
            #plt.title(param_dict[paramname], fontname = "Cambria", style = 'italic', fontsize = 24, y = 1.2)
            fname = os.path.join(imgfolder, "{}_{}_{}.png".format(paramname, valname, t))
            plt.savefig(fname, bbox_inches='tight')

# %%

# %%
