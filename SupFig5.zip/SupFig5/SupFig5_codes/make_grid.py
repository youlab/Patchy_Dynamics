#GRID
#%% 
import os
import matplotlib.pyplot as plt
from mpl_toolkits.axes_grid1 import ImageGrid
from PIL import Image

ts = [84, 240]
imgfolder = "317_plots_v2"
imlst = []
#ORDER C_m, xi (formerly epsi), D_b,  D_a, d_b, A_th, kappa_b, gamma
param_lst = [ 'Cm', 'epsi', 'DB','DA', 'ddB', 'Ath','kappaB', 'gamma']
vallist = ["fracnotzero", "max_patch", "gini", "total_biomass"]  

for t in ts:
    for valname in vallist:
        for paramname in param_lst:
            fname = os.path.join(imgfolder, "{}_{}_{}.png".format(paramname, valname, t))
            img = Image.open(fname)
            imlst.append(img)

    fig = plt.figure(figsize=(3.96*8, 3.16*4))  #3 times larger - hopefully clearer. --nvm DELETED X3. 
    grid = ImageGrid(fig, 111,  # similar to subplot(111)
                    nrows_ncols=(4, 8),  # creates 2x2 grid of axes
                    axes_pad=0.05, # pad between axes in inch.
                    share_all = True)

    for ax, im in zip(grid, imlst):
        # Iterating over the grid returns the Axes.
        ax.imshow(im)
        # ax.set_xticklabels([])
        # ax.set_yticklabels([])
        ax.tick_params(which='both',
                       labelbottom = False, labeltop = False, labelleft = False, labelright = False, 
                       bottom = False, top = False, left = False, right = False)
        for spine in ax.spines.values():
            spine.set_edgecolor('white')

    fname = "image_grid_{}_v2_300dpi_pdf.pdf".format(t)
    plt.savefig(fname, dpi = 300., bbox_inches='tight')
# %%
