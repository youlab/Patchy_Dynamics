#re-plot, make prettier. 
#%% 
from matplotlib import pyplot as plt
import numpy as np

data = np.ones((2, 10))
fig, ax = plt.subplots()
plt.plot(data[0,:], data[1,:], label = "0.25×", color ='#7C5C00', linewidth = 2) #all was 2 
plt.plot(data[0,:], data[1,:], label = "0.5×", color ='#C00000', linewidth = 2)
plt.plot(data[0,:], data[1,:], label = "1×", color ='#000000', linewidth = 2)
#EPS
# plt.plot(data[0,:], data[1,:], label = "1.25×", color ='#B4C7E7', linewidth = 2)
# fig.legend(loc='upper right', ncol = 4, prop={'size': 20, 'family': 'Arial'}, handletextpad = 0.2, columnspacing = 0.5, bbox_to_anchor=(1, 1))

#ELSE
plt.plot(data[0,:], data[1,:], label = "2×", color ='#B4C7E7', linewidth = 2)
plt.plot(data[0,:], data[1,:], label = "4×", color = '#FFC000', linewidth = 2)


#no change case
ax.axis(False)
#change col to 4 or 5..
fig.legend(loc='upper right', ncol = 5, prop={'size': 20, 'family': 'Arial'}, handletextpad = 0.2, columnspacing = 0.5, bbox_to_anchor=(1, 1))
plt.savefig("legend_nochange_pdf.pdf", bbox_inches = 'tight')

#legend only case. 
#https://stackoverflow.com/questions/60732708/save-matplotlib-legend-as-a-separate-image
# label_params = ax.get_legend_handles_labels() 
# figl, axl = plt.subplots()
# axl.axis(False)
#, bbox_to_anchor=(1, 1)
#axl.legend(*label_params, loc='center', ncol = 5, prop={'size': 40, 'family': 'Arial'}, handletextpad = 0.4, columnspacing = 1)
#figl.savefig("legend_high_res_thicklines.pdf", bbox_inches = 'tight')
# %%
